import json
import boto3

lambda_client = boto3.client('lambda')

def lambda_handler(event, context):
    try:
        for record in event['Records']:
            # Parse SQS message
            message_body = json.loads(record['body'])

            # Invoke main notification processor
            response = lambda_client.invoke(
                FunctionName=os.environ['MAIN_LAMBDA_ARN'],
                InvocationType='Event',  # Asynchronous invocation
                Payload=json.dumps(message_body)
            )

            print(f"Processed notification: {message_body.get('notificationType')}")

        return {
            'statusCode': 200,
            'body': json.dumps('Successfully processed SQS messages')
        }

    except Exception as e:
        print(f"Error processing SQS messages: {str(e)}")
        raise e
