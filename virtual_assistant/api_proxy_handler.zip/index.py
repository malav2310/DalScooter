import json
import boto3
import os
import logging
import uuid

logger = logging.getLogger()
logger.setLevel(logging.INFO)

lex_client = boto3.client('lexv2-runtime')

def handler(event, context):
    """
    API Gateway proxy function that communicates with Lex V2
    """
    logger.info(f"Received API Gateway event: {json.dumps(event)}")
    
    try:
        # Handle CORS preflight
        if event.get('httpMethod') == 'OPTIONS':
            return {
                'statusCode': 200,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
                },
                'body': ''
            }
        
        # Parse request body
        if event.get('body'):
            if event.get('isBase64Encoded'):
                body = json.loads(base64.b64decode(event['body']).decode('utf-8'))
            else:
                body = json.loads(event['body'])
        else:
            return create_error_response(400, "Missing request body")
        
        # Extract required parameters
        message = body.get('message', '')
        session_id = body.get('sessionId', str(uuid.uuid4()))
        
        if not message:
            return create_error_response(400, "Message is required")
        
        # Call Lex V2 RecognizeText API
        response = lex_client.recognize_text(
            botId=os.environ['BOT_ID'],
            botAliasId=os.environ['BOT_ALIAS_ID'],
            localeId='en_US',
            sessionId=session_id,
            text=message
        )
        
        # Extract response message
        bot_response = ""
        if 'messages' in response and response['messages']:
            bot_response = response['messages'][0].get('content', '')
        
        # Return formatted response
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'message': bot_response,
                'sessionId': session_id,
                'dialogState': response.get('sessionState', {}).get('dialogAction', {}).get('type', ''),
                'intentName': response.get('sessionState', {}).get('intent', {}).get('name', ''),
                'slotToElicit': response.get('sessionState', {}).get('dialogAction', {}).get('slotToElicit', ''),
                'sessionAttributes': response.get('sessionState', {}).get('sessionAttributes', {}),
                'requestAttributes': response.get('requestAttributes', {})
            })
        }
        
    except Exception as e:
        logger.error(f"Error processing request: {str(e)}")
        return create_error_response(500, f"Internal server error: {str(e)}")

def create_error_response(status_code, message):
    """Create error response"""
    return {
        'statusCode': status_code,
        'headers': {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
            'Content-Type': 'application/json'
        },
        'body': json.dumps({
            'error': message
        })
    }
