import json
import boto3
import os
import logging
from datetime import datetime
import uuid

logger = logging.getLogger()
logger.setLevel(logging.INFO)

dynamodb = boto3.resource('dynamodb')

def handler(event, context):
    """
    Router function that directs intents to appropriate handlers
    """
    logger.info(f"Received event: {json.dumps(event)}")
    
    try:
        intent_name = event['sessionState']['intent']['name']
        
        if intent_name == 'FAQIntent':
            return handle_faq(event, context)
        elif intent_name == 'BookingIntent':
            return handle_booking(event, context)
        elif intent_name == 'ConcernIntent':
            return handle_concern(event, context)
        else:
            return default_response(event, intent_name)
            
    except Exception as e:
        logger.error(f"Router error: {str(e)}")
        return error_response(event.get('sessionState', {}).get('intent', {}).get('name', 'Unknown'))

def handle_faq(event, context):
    """Handle FAQ queries"""
    try:
        table = dynamodb.Table(os.environ['KNOWLEDGE_BASE_TABLE'])
        input_text = event.get('inputTranscript', '').lower()
        
        # Define FAQ responses
        faq_responses = {
            'register': """To register for DALScooter:
1. Visit our registration page
2. Fill in your personal details
3. Create a username and password
4. Verify your email address
5. Complete the multi-factor authentication setup
Once registered, you'll receive a confirmation notification!""",
            
            'bikes': """We offer three types of bikes:
1. **Gyroscooter** - Perfect for short city rides
2. **eBikes** - Electric bikes for longer distances
3. **Segway** - Self-balancing personal transporters

You can check availability and rates for each type on our main page.""",
            
            'cost': """Our rental rates vary by bike type:
- Gyroscooter: Starting from $5/hour
- eBikes: Starting from $8/hour  
- Segway: Starting from $10/hour

Registered customers may receive special discounts! Please check our rates page for current pricing.""",
            
            'booking': """To make a booking:
1. Register and log in to your account
2. Select your preferred bike type
3. Choose your rental period
4. Confirm your booking
5. You'll receive a booking reference code
6. Use this code to get your bike access code through me!""",
            
            'help': """I can help you with:
- Registration process
- Available bike types and rates
- How to make bookings
- Getting your bike access code (with booking reference)
- Reporting issues or concerns
- General navigation around the site

What would you like to know more about?"""
        }
        
        # Try to find matching FAQ
        for keyword, response in faq_responses.items():
            if keyword in input_text:
                return create_response('FAQIntent', 'Fulfilled', response)
        
        # Default FAQ response
        return create_response('FAQIntent', 'Fulfilled', """I'd be happy to help! I can assist you with:

• How to register and create an account
• Information about our bike types (Gyroscooter, eBikes, Segway)
• Rental rates and pricing
• How to make bookings
• Getting your bike access code
• Reporting issues or problems
• General site navigation

Please ask me about any of these topics, or try rephrasing your question!""")
        
    except Exception as e:
        logger.error(f"FAQ handler error: {str(e)}")
        return error_response('FAQIntent')

def handle_booking(event, context):
    """Handle booking reference queries"""
    try:
        table = dynamodb.Table(os.environ['BOOKING_REFERENCES_TABLE'])
        slots = event['sessionState']['intent'].get('slots', {})
        
        # Get booking reference from slot
        booking_reference = None
        if 'BookingReference' in slots and slots['BookingReference'] and slots['BookingReference']['value']:
            booking_reference = slots['BookingReference']['value']['interpretedValue']
        
        if not booking_reference:
            return create_response('BookingIntent', 'Fulfilled', 
                "Please provide your booking reference number so I can help you get your bike access code and rental details.")
        
        # Query the booking references table
        response = table.get_item(Key={'booking_reference': booking_reference})
        
        if 'Item' in response:
            item = response['Item']
            bike_type = item.get('bike_type', 'N/A')
            bike_number = item.get('bike_number', 'N/A')
            access_code = item.get('access_code', 'N/A')
            start_time = item.get('start_time', 'N/A')
            end_time = item.get('end_time', 'N/A')
            rental_duration = item.get('rental_duration', 'N/A')
            status = item.get('status', 'active')
            
            if status.lower() == 'active':
                message = f"""✅ **Booking Details Found**

🔖 **Booking Reference:** {booking_reference}
🚲 **Bike Type:** {bike_type}
🏷️ **Bike Number:** {bike_number}
🔐 **Access Code:** {access_code}
⏰ **Rental Period:** {start_time} to {end_time}
⏱️ **Duration:** {rental_duration}

**Instructions:**
1. Locate bike #{bike_number}
2. Enter access code: {access_code}
3. Enjoy your ride!

Need help finding your bike or have any issues? Just let me know!"""
            else:
                message = f"""📋 **Booking Status Update**

🔖 **Booking Reference:** {booking_reference}
📊 **Status:** {status.title()}

This booking is no longer active. If you need assistance, please contact our support team or make a new booking."""
        else:
            message = f"""❌ **Booking Not Found**

I couldn't find any booking with reference: **{booking_reference}**

Please check:
✓ Your booking reference is correct
✓ The booking is still active
✓ You're logged in to the correct account

If you're still having trouble, please contact our support team for assistance."""
        
        return create_response('BookingIntent', 'Fulfilled', message)
        
    except Exception as e:
        logger.error(f"Booking handler error: {str(e)}")
        return error_response('BookingIntent')

def handle_concern(event, context):
    """Handle customer concerns"""
    try:
        table = dynamodb.Table(os.environ['CUSTOMER_CONCERNS_TABLE'])
        slots = event['sessionState']['intent'].get('slots', {})
        input_text = event.get('inputTranscript', '')
        
        # Get booking reference from slot if available
        booking_reference = None
        if 'BookingReference' in slots and slots['BookingReference'] and slots['BookingReference']['value']:
            booking_reference = slots['BookingReference']['value']['interpretedValue']
        
        # Use the full input text as issue description if no specific slot
        issue_description = input_text if input_text else "General issue reported"
        
        # Generate unique concern ID
        concern_id = str(uuid.uuid4())
        timestamp = datetime.utcnow().isoformat()
        
        # Determine priority and category
        priority = determine_priority(issue_description)
        category = determine_category(issue_description)
        
        # Create concern item
        concern_item = {
            'concern_id': concern_id,
            'booking_reference': booking_reference or 'N/A',
            'issue_description': issue_description,
            'status': 'open',
            'created_at': timestamp,
            'updated_at': timestamp,
            'priority': priority,
            'category': category
        }
        
        # Save to DynamoDB
        table.put_item(Item=concern_item)
        
        message = f"""🎫 **Issue Ticket Created Successfully**

📋 **Ticket ID:** {concern_id[:8]}...
🔖 **Booking Reference:** {booking_reference or 'Not provided'}
📝 **Issue:** {issue_description}
📊 **Status:** Open
⚡ **Priority:** {priority.title()}

**What happens next:**
✅ Your concern has been logged and forwarded to our franchise operators
✅ You'll receive updates on the resolution progress
✅ Expected response time: 2-4 hours for urgent issues, 24 hours for others

**For immediate assistance:**
• If this is a safety issue, please contact emergency services
• For urgent bike problems, you can also call our 24/7 hotline

Thank you for reporting this issue. We'll resolve it as quickly as possible!"""
        
        return create_response('ConcernIntent', 'Fulfilled', message)
        
    except Exception as e:
        logger.error(f"Concern handler error: {str(e)}")
        return error_response('ConcernIntent')

def determine_priority(issue_description):
    """Determine priority based on issue description"""
    issue_lower = issue_description.lower()
    high_priority_keywords = ['accident', 'injury', 'broken', 'damaged', 'safety', 'emergency', 'stuck', 'theft']
    medium_priority_keywords = ['battery', 'not working', 'malfunction', 'dead', 'cannot unlock', 'won\'t start']
    
    for keyword in high_priority_keywords:
        if keyword in issue_lower:
            return 'high'
    
    for keyword in medium_priority_keywords:
        if keyword in issue_lower:
            return 'medium'
    
    return 'low'

def determine_category(issue_description):
    """Determine category based on issue description"""
    issue_lower = issue_description.lower()
    categories = {
        'technical': ['battery', 'not working', 'malfunction', 'broken', 'dead', 'won\'t start', 'charging'],
        'access': ['cannot unlock', 'access code', 'locked', 'unlock'],
        'damage': ['damaged', 'broken', 'scratched', 'dent'],
        'safety': ['accident', 'injury', 'safety', 'emergency'],
        'theft': ['stolen', 'theft', 'missing'],
    }
    
    for category, keywords in categories.items():
        for keyword in keywords:
            if keyword in issue_lower:
                return category
    
    return 'other'

def create_response(intent_name, state, message):
    """Create standard Lex response"""
    return {
        'sessionState': {
            'dialogAction': {
                'type': 'Close'
            },
            'intent': {
                'name': intent_name,
                'state': state
            }
        },
        'messages': [{
            'contentType': 'PlainText',
            'content': message
        }]
    }

def default_response(event, intent_name):
    """Default response for unknown intents"""
    return create_response(intent_name, 'Fulfilled', 
        "I'm sorry, I couldn't understand your request. Please try asking about registration, bike access codes, or reporting issues.")

def error_response(intent_name):
    """Error response"""
    return create_response(intent_name, 'Failed', 
        "I apologize, but I'm experiencing technical difficulties. Please try again or contact support.")
